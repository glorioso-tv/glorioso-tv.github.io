# -*- coding: utf-8 -*-
import xbmc
from lib.proxy import proxyOverride

def run():
    # Inicia o proxy na porta 8888
    proxy = proxyOverride(port=8888)
    
    # Mantem o servico rodando ate o Kodi fechar
    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(10):
            break
    
    # Para o proxy ao sair
    proxy.stop_proxy()

if __name__ == '__main__':
    run()