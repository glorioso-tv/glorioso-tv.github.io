# -*- coding: utf-8 -*-
import requests
import logging
import os
from urllib.parse import quote


logging.basicConfig(
    level=logging.INFO,
    format='%(message)s'
)
logger = logging.getLogger(__name__)

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:129.0) Gecko/20100101 Firefox/129.0'
PROXY = 'http://127.0.0.1:8081/?url='

class cfscraper:
    session = requests.Session()
    
    @classmethod
    def get(cls, url, headers=None, timeout=None, allow_redirects=True, cookies=None, direct=True):
        if headers is None: headers = {}
        if cookies is None: cookies = {}
        sess = cls.session
        proxy_url = PROXY + quote(url)
        
        # Garante User-Agent
        if not any(k.lower() == 'user-agent' for k in headers):
            headers['User-Agent'] = USER_AGENT

        target_url = url if direct else proxy_url

        try:
            res = sess.get(target_url, headers=headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
            res.raise_for_status()            
            return res
        except requests.exceptions.HTTPError as err:
            if err.response.status_code in [403, 503]:                
                try:
                    headers_str = '&'.join([f"{k}={quote(v)}" for k,v in headers.items()])
                    proxy_url_headers = PROXY + quote(url + '|' + headers_str)
                    res = sess.get(proxy_url_headers, headers={}, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                    res.raise_for_status()            
                    return res
                except Exception:
                    # Retorna a resposta de erro original se o proxy falhar
                    return err.response
            else:
                logger.error("HTTP error occurred: {0}".format(err))
                return err.response
        except Exception as e:
            try:
                res = sess.get(proxy_url, headers=headers, cookies=cookies, allow_redirects=allow_redirects, timeout=timeout)
                res.raise_for_status()            
                return res
            except Exception as e_proxy:
                logger.error("HTTP error occurred: {0}".format(e_proxy)) 
        return None

    @classmethod
    def post(cls, url, headers=None, timeout=None, data=None, json=None, allow_redirects=True, cookies=None, direct=True):
        if headers is None: headers = {}
        if cookies is None: cookies = {}
        sess = cls.session
        
        if not any(k.lower() == 'user-agent' for k in headers):
            headers['User-Agent'] = USER_AGENT
            
        try:
            if data:
                res = sess.post(url,headers=headers, data=data, allow_redirects=allow_redirects, cookies=cookies, timeout=timeout)
            else:
                res = sess.post(url,headers=headers, json=json, allow_redirects=allow_redirects, cookies=cookies, timeout=timeout)
            res.raise_for_status()
            return res
        except requests.exceptions.HTTPError as err:
            if err.response.status_code in [403, 503]:
                try:
                    headers_str = '&'.join([f"{k}={quote(v)}" for k,v in headers.items()])
                    proxy_url = PROXY + quote(url + '|' + headers_str)
                    if data:
                        res = sess.post(proxy_url, headers={}, data=data, allow_redirects=allow_redirects, cookies=cookies, timeout=timeout)
                    else:
                        res = sess.post(proxy_url, headers={}, json=json, allow_redirects=allow_redirects, cookies=cookies, timeout=timeout)
                    res.raise_for_status()            
                    return res
                except Exception:
                    return err.response
            else:
                logger.error("HTTP error occurred: {0}".format(err))
                return err.response
        except Exception as e:
            try:
                headers_str = '&'.join([f"{k}={quote(v)}" for k,v in headers.items()])
                proxy_url = PROXY + quote(url + '|' + headers_str)
                if data:
                    res = sess.post(proxy_url, headers={}, data=data, allow_redirects=allow_redirects, cookies=cookies, timeout=timeout)
                else:
                    res = sess.post(proxy_url, headers={}, json=json, allow_redirects=allow_redirects, cookies=cookies, timeout=timeout)
                res.raise_for_status()            
                return res
            except Exception as e:
                logger.error("HTTP error occurred: {0}".format(e))
        return None 
                                
