import sys
import random
import socket
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
from urllib.parse import urlparse, parse_qs, unquote
import threading

try:
    import xbmc
except ImportError:
    xbmc = None

# Integração com CustomDNS para evitar travamentos e erros de resolução
try:
    from lib.customdns import DNSOverride
    dns_override = DNSOverride()
    if xbmc:
        xbmc.log("CustomDNS ativado no proxy.py", xbmc.LOGINFO)
except Exception as e:
    if xbmc:
        xbmc.log(f"Erro ao ativar CustomDNS no proxy: {str(e)}", xbmc.LOGERROR)

# User-Agents para evitar bloqueios
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; SM-S901B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
]

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True

class ProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Extrai a URL do parâmetro ?url=
        query_components = parse_qs(urlparse(self.path).query)
        if 'url' not in query_components:
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Proxy Ativo. Use ?url=sua_url")
            return

        target_url = query_components['url'][0]
        
        req_headers = {}
        if '|' in target_url:
            target_url, headers_str = target_url.split('|', 1)
            for pair in headers_str.split('&'):
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    req_headers[key] = unquote(value)
        
        try:
            # Configura a requisição para o destino
            req = urllib.request.Request(target_url)
            req.add_header('User-Agent', random.choice(USER_AGENTS))
            req.add_header('Accept', '*/*')
            for k, v in req_headers.items():
                req.add_header(k, v)

            # Abre a conexão e lê o conteúdo
            with urllib.request.urlopen(req, timeout=30) as response:
                self.send_response(response.getcode())
                
                # Filtra headers para o player do Kodi
                excluded = ["content-encoding", "transfer-encoding", "connection", "host"]
                for header, value in response.getheaders():
                    if header.lower() not in excluded:
                        self.send_header(header, value)
                self.end_headers()

                # Transmite os dados (streaming) em pedaços (chunks)
                while True:
                    try:
                        chunk = response.read(1024 * 32) # 32KB por vez
                        if not chunk:
                            break
                        self.wfile.write(chunk)
                    except (BrokenPipeError, ConnectionResetError):
                        # Cliente (Kodi) fechou a conexão, parar streaming
                        break
        except Exception as e:
            self.send_error(502, f"Erro no Proxy: {str(e)}")

    # Permite POST caso o addon precise
    def do_POST(self):
        self.do_GET()

def run_proxy(port=8081):
    server_address = ('', port)
    try:
        if xbmc:
            xbmc.log(f"[TV FOGO] Iniciando proxy na porta {port}", xbmc.LOGINFO)
        else:
            print(f"Iniciando proxy na porta {port}")

        httpd = ThreadedHTTPServer(server_address, ProxyHandler)
        # O servidor rodará aqui até o Kodi ser fechado (ou o addon parar)
        httpd.serve_forever()
    except Exception as e:
        log_msg = f"[TV FOGO] Erro ao iniciar o proxy: {e}"
        if xbmc:
            xbmc.log(log_msg, xbmc.LOGERROR)
        else:
            print(log_msg)

if __name__ == "__main__":
    run_proxy()
