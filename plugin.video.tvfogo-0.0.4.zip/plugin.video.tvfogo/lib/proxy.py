import random
import threading
import socket
import requests
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, unquote
from lib.customdns import DNSOverride
dns_override = DNSOverride()

try:
    import xbmc
except ImportError:
    xbmc = None


# User-Agents para compatibilidade total (IPTV e Sites de Regex)
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "AppleCoreMedia/1.0.0.19E241 (iPhone; U; CPU OS 15_4 like Mac OS X; pt_br)",
    "VLC/3.0.18 LibVLC/3.0.18",
    "IPTVSmarters/1.0.0"
]

class ProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args): return 

    def do_HEAD(self):
        self.do_GET(just_headers=True)

    def do_GET(self, just_headers=False):
        query_components = parse_qs(urlparse(self.path).query)
        if 'url' not in query_components:
            self.send_response(200)
            self.send_header('Content-type', 'text/plain')
            self.end_headers()
            self.wfile.write(b"Proxy Ativado")
            return

        # Descodifica a URL (Regex costuma vir codificado)
        target_url = unquote(query_components['url'][0])
        req_headers = {}
        
        # Suporte a links de Regex com múltiplos Headers (Pipe '|')
        if '|' in target_url:
            parts = target_url.split('|')
            target_url = parts[0]
            header_str = parts[1]
            for pair in header_str.split('&'):
                if '=' in pair:
                    k, v = pair.split('=', 1)
                    req_headers[k] = v
        
        # Se não houver User-Agent no link, usa um aleatório
        if 'User-Agent' not in req_headers:
            req_headers['User-Agent'] = random.choice(USER_AGENTS)
            
        if 'Range' in self.headers:
            req_headers['Range'] = self.headers['Range']

        try:
            session = requests.Session()
            method = session.head if just_headers else session.get
            
            # allow_redirects=True resolve links de Regex que pulam de um site para outro
            with method(target_url, headers=req_headers, stream=True, timeout=30, verify=False, allow_redirects=True) as r:
                self.send_response(r.status_code)
                
                excluded = ['content-encoding', 'transfer-encoding', 'connection', 'content-length', 'host', 'server']
                for key, value in r.headers.items():
                    if key.lower() not in excluded:
                        self.send_header(key, value)
                
                if 'Content-Length' in r.headers:
                    self.send_header('Content-Length', r.headers['Content-Length'])
                
                self.end_headers()

                if not just_headers:
                    for chunk in r.iter_content(chunk_size=131072):
                        if chunk:
                            try:
                                self.wfile.write(chunk)
                            except:
                                break
                            
        except Exception as e:
            if xbmc: xbmc.log(f"[Proxy] Erro: {str(e)}", xbmc.LOGERROR)
            try: self.send_error(502)
            except: pass

class proxyOverride:
    def __init__(self, port=8888):
        self.port = port
        self.httpd = None
        self.thread = None
        
        if not self._is_port_in_use():
            self.start_proxy()
        else:
            if xbmc: xbmc.log("Proxy Ativado", xbmc.LOGINFO)

    def _is_port_in_use(self):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(1)
            return s.connect_ex(('127.0.0.1', self.port)) == 0

    def start_proxy(self):
        try:
            self.httpd = HTTPServer(('', self.port), ProxyHandler)
            self.httpd.allow_reuse_address = True
            self.thread = threading.Thread(target=self.httpd.serve_forever)
            self.thread.daemon = True
            self.thread.start()
            if xbmc: xbmc.log("Proxy Ativado", xbmc.LOGINFO)
        except Exception:
            pass

    def stop_proxy(self):
        if self.httpd:
            self.httpd.shutdown()
            self.httpd.server_close()