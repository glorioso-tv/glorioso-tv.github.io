Templates de advancedsettings.xml para Kodi 21.x (Omega).

Tags removidas no Kodi v21:
- cache / memorysize / buffermode / readfactor / chunksize
- Essas opcoes foram movidas para a GUI de configuracoes do Kodi.

Arquivos:
- advancedsettings_kodi20_21.xml          (network recomendado)
- advancedsettings_minimal_kodi20_21.xml  (network minimo)
- advancedsettings_kodi21_3.xml           (network recomendado para Kodi 21.3)
- advancedsettings_kodi20_or_older.xml    (cache + network para Kodi antigo)

Uso:
1) Copie o conteúdo para userdata/advancedsettings.xml do Kodi.
2) Reinicie o Kodi.
