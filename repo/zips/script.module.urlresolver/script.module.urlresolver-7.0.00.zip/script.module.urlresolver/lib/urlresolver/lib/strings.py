"""
    URLResolver Addon for Kodi
    Copyright (C) 2016 t0mm0, tknorris

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
"""

STRINGS = {
    'ol_auth_header': 33000,
    'auth_required': 33001,
    'visit_link': 33002,
    'click_pair': 33003,
    'no_ol_auth': 33004,
    'auto_update': 33005,
    'update_url': 33006,
    'decrypt_key': 33007,
    'vevio_auth_header': 33008,
    'vidup_auth_header': 33009,
    'enable_universal': 33010,
    'auto_pick': 33011,
    'use_function_cache': 33012,
    'reset_function_cache': 33013,
    'universal_resolvers': 33014,
    'resolvers': 33015,
    'priority': 33016,
    'enabled': 33017,
    'rd_authorized': 33018,
    'rd_auth_reset': 33019,
    'cache_reset': 33020,
    'cache_reset_failed': 33021,
    'login': 33022,
    'username': 33023,
    'password': 33024,
    'use_https': 33025,
    'customer_id': 33026,
    'pin': 33027,
    'auto_primary_link': 33028,
    'auth_my_account': 33029,
    'reset_my_auth': 33030,
    'resolver_updated': 33031,
    'letters_image': 33032,
    'captcha_error': 33033,
    'choose_the_link': 33034,
    'no_link_selected': 33035,
    'no_video_link': 33036,
    'captcha_round': 33037,
    'cancel': 33038,
    'ok': 33039,
    'stream_auth_header': 33040,
    'no_ip_authorization': 33041,
    'client_id': 33042,
    'vshareeu_auth_header': 33043,
    'flashx_auth_header': 33044,
    'ad_auth_reset': 33045,
    'ad_authorized': 33046,
    'enable_popups': 33047,
    'api_key': 33048,
    'torrents': 33049,
    'cached_only': 33050,
    'pm_auth_reset': 33051,
    'pm_authorized': 33052,
    'ls_auth_reset': 33053,
    'ls_authorized': 33054,
    'download_rate': 33055,
    'peer_number': 33056,
    'seconds': 33057,
    'cached_files_only': 33058,
    'jetload_auth_header': 33059,
    'uptobox_auth_header': 33060,
    'upto_link': 33061,
    'upto_pair': 33062,
    'dl_auth_reset': 33063,
    'dl_authorized': 33064,
    'clear_finished': 33065,
    'minutes': 33066,
    'hours': 33067,
    'ub_auth_reset': 33068,
    'ub_authorized': 33069,
}
