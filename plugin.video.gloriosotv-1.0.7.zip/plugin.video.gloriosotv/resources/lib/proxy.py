import sys
import random
import urllib.request
import urllib.error
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs, unquote
import threading

try:
    import xbmc
except ImportError:
    xbmc = None

# User-Agents para evitar bloqueios
USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Linux; Android 13; SM-S901B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
]

class ProxyHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Extrai a URL do parâmetro ?url=
        query_components = parse_qs(urlparse(self.path).query)
        if 'url' not in query_components:
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Proxy Ativo. Use ?url=sua_url")
            return

        target_url = query_components['url'][0]
        
        req_headers = {}
        if '|' in target_url:
            target_url, headers_str = target_url.split('|', 1)
            for pair in headers_str.split('&'):
                if '=' in pair:
                    key, value = pair.split('=', 1)
                    req_headers[key] = unquote(value)
        
        try:
            # Configura a requisição para o destino
            req = urllib.request.Request(target_url)
            req.add_header('User-Agent', random.choice(USER_AGENTS))
            req.add_header('Accept', '*/*')
            for k, v in req_headers.items():
                req.add_header(k, v)

            # Abre a conexão e lê o conteúdo
            with urllib.request.urlopen(req, timeout=30) as response:
                self.send_response(response.getcode())
                
                # Filtra headers para o player do Kodi
                excluded = ["content-encoding", "transfer-encoding", "connection", "host"]
                for header, value in response.getheaders():
                    if header.lower() not in excluded:
                        self.send_header(header, value)
                self.end_headers()

                # Transmite os dados (streaming) em pedaços (chunks)
                while True:
                    chunk = response.read(1024 * 32) # Aumentar de 16KB para 32KB ajuda em conexões fibra
                    if not chunk:
                        break
                    self.wfile.write(chunk)

        except Exception as e:
            self.send_error(502, f"Erro no Proxy: {str(e)}")

    # Permite POST caso o addon precise
    def do_POST(self):
        self.do_GET()

def run_proxy(port=8080):
    server_address = ('', port)
    try:
        httpd = HTTPServer(server_address, ProxyHandler)
    except Exception as e:
        if xbmc:
            xbmc.log(f"Erro ao criar servidor proxy: {str(e)}", xbmc.LOGERROR)
        else:
            print(f"Erro ao criar servidor proxy: {str(e)}")
        return
    
    if xbmc:
        xbmc.log(f"Proxy local rodando na porta {port}...", xbmc.LOGINFO)
        t = threading.Thread(target=httpd.serve_forever)
        t.start()
        monitor = xbmc.Monitor()
        while not monitor.abortRequested():
            monitor.waitForAbort(1)
        httpd.shutdown()
        t.join()
    else:
        print(f"Proxy local rodando na porta {port}...")
        httpd.serve_forever()

if __name__ == "__main__":
    run_proxy()