import sys
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
from resources.lib import cleaner_logic # Vamos criar essa lógica separada

addon = xbmcaddon.Addon()
handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1

def menu():
    # Itens do Menu em PT-BR
    itens = [
        ("Limpeza Total (Tudo)", "all"),
        ("Limpar Cache e Temporários", "cache"),
        ("Limpar Miniaturas (Thumbnails)", "thumbs"),
        ("Limpar Pacotes ZIP", "packages"),
        ("Otimizar Banco de Dados", "database"),
        ("Configurações", "settings")
    ]
    
    for nome, acao in itens:
        url = f"{sys.argv[0]}?action={acao}"
        list_item = xbmcgui.ListItem(label=nome)
        xbmcplugin.addDirectoryItem(handle, url, list_item, False)
    
    xbmcplugin.endOfDirectory(handle)

if __name__ == '__main__':
    params = dict(arg.split('=') for arg in sys.argv[2][1:].split('&') if '=' in arg)
    action = params.get('action')

    if action == "settings":
        addon.openSettings()
    elif action == "all":
        cleaner_logic.limpar_tudo()
    elif action:
        cleaner_logic.executar_especifico(action)
    else:
        menu()
