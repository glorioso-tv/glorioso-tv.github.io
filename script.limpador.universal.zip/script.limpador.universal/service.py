import xbmc
import xbmcaddon
import time
from resources.lib import cleaner_logic

addon = xbmcaddon.Addon()

class LimpadorService(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        
    def rodar(self):
        atraso = int(addon.getSetting("atraso_inicial"))
        xbmc.log(f"Limpador Universal: Aguardando {atraso}s para iniciar...", xbmc.LOGINFO)
        
        if self.waitForAbort(atraso): return
        
        # Executa a manutenção baseada nas settings
        cleaner_logic.manutencao_automatica()

if __name__ == '__main__':
    service = LimpadorService()
    service.rodar()
