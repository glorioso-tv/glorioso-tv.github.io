# -*- coding: utf-8 -*-
import xbmc
import xbmcgui
import xbmcvfs
import os
import shutil
import sqlite3

def limpar_pasta(caminho_kodi):
    """Apaga ficheiros e subpastas de um caminho 'special://'"""
    caminho_real = xbmcvfs.translatePath(caminho_kodi)
    if xbmcvfs.exists(caminho_real):
        diretorios, ficheiros = xbmcvfs.listdir(caminho_real)
        for f in ficheiros:
            try:
                xbmcvfs.delete(os.path.join(caminho_real, f))
            except: continue
        for d in diretorios:
            try:
                shutil.rmtree(os.path.join(caminho_real, d), ignore_errors=True)
            except: continue

def otimizar_db():
    """Compacta bases de dados e limpa biblioteca de vídeo"""
    xbmc.executebuiltin('CleanLibrary(video)')
    db_path = xbmcvfs.translatePath("special://database")
    if xbmcvfs.exists(db_path):
        _, ficheiros = xbmcvfs.listdir(db_path)
        for db in ficheiros:
            if db.endswith('.db'):
                try:
                    conn = sqlite3.connect(os.path.join(db_path, db))
                    conn.execute("VACUUM")
                    conn.close()
                except: continue

def limpar_tudo(silencioso=False):
    """Limpeza total ajustada para Flatpak/Apt/Android/Windows"""
    if not silencioso:
        pdp = xbmcgui.DialogProgress()
        pdp.create('Limpador Universal', 'A iniciar faxina geral...')
    
    # 1. Limpeza de Temporários e Cache
    if not silencioso: pdp.update(25, 'A limpar Cache e Temporários...')
    limpar_pasta('special://temp')
    
    # 2. Limpeza de Thumbnails e Reset de Texturas (Resolve o problema das imagens sumirem)
    if not silencioso: pdp.update(50, 'A limpar Miniaturas e Banco de Imagens...')
    limpar_pasta('special://thumbnails')
    
    # Apaga o banco de texturas para o Kodi não mostrar ícones vazios
    db_texturas = xbmcvfs.translatePath('special://database/Textures13.db')
    if xbmcvfs.exists(db_texturas):
        try: xbmcvfs.delete(db_texturas)
        except: pass

    # 3. Limpeza de Pacotes (Arquivos ZIP antigos)
    if not silencioso: pdp.update(75, 'A remover pacotes de addons antigos...')
    limpar_pasta('special://home/addons/packages')
    
    # 4. Otimização de Sistema
    if not silencioso: pdp.update(90, 'A otimizar bancos de dados...')
    otimizar_db()
    
    if not silencioso:
        pdp.close()
        # Menu final para decidir se quer reiniciar ou continuar
        escolha = xbmcgui.Dialog().yesno('Limpeza Concluída', 
            'A limpeza foi um sucesso!\n'
            'O banco de imagens foi resetado para evitar erros.\n'
            'Deseja fechar o Kodi para aplicar todas as mudanças agora?')
        
        if escolha:
            # Comando universal para fechar o Kodi em qualquer plataforma
            xbmc.executebuiltin('Quit')

def executar_especifico(acao):
    """Executa limpeza por categoria via menu principal"""
    if acao == 'cache':
        limpar_pasta('special://temp')
    elif acao == 'thumbs':
        limpar_pasta('special://thumbnails')
        db_texturas = xbmcvfs.translatePath('special://database/Textures13.db')
        if xbmcvfs.exists(db_texturas): xbmcvfs.delete(db_texturas)
    elif acao == 'packages':
        limpar_pasta('special://home/addons/packages')
    elif acao == 'database':
        otimizar_db()
    
    xbmcgui.Dialog().notification('Limpador', 'Tarefa concluída!', xbmcgui.NOTIFICATION_INFO, 3000)

def manutencao_automatica():
    """Função chamada pelo service.py (respeita as configurações do usuário)"""
    import xbmcaddon
    addon = xbmcaddon.Addon()
    
    # Só roda se estiver ativado nas settings
    if addon.getSettingBool('limpar_cache_enable'):
        limpar_pasta('special://temp')
    if addon.getSettingBool('limpar_thumbs_enable'):
        limpar_pasta('special://thumbnails')
        # No automático, evitamos apagar o Textures13.db para não assustar o usuário com imagens sumindo
    if addon.getSettingBool('limpar_pacotes_enable'):
        limpar_pasta('special://home/addons/packages')
    if addon.getSettingBool('otimizar_db_enable'):
        otimizar_db()
